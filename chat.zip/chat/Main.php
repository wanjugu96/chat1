<?php
session_start();

?>

<!DOCTYPE html>
<?php
include_once('CSDL/db.php');


$email = $_SESSION['user'];
$pass = $_SESSION['mk'];

// sửa thông tin
if (isset($_POST ["btn_save"])) {
    $firstname= $_POST["FFirst"];
    $lastname=   $_POST["LLast"];


    $sql = ("UPDATE user SET LastName = '$lastname',  FirstName = '$firstname'  WHERE email = '$email'")or die("hẹo" . mysql_error());
$query = mysql_query($sql);




}
// đổi mật khẩu
if (isset($_POST ["btn_doiMk"])) {

    $matkhaucu =$_POST["MkCu"];
    $matkhaummoi1 =$_POST["Mkmoi"];
    $matkhaummoi2 =$_POST["nMkmoi"];
    if ( $matkhaucu == $pass && $matkhaummoi1 == $matkhaummoi2 && $matkhaummoi1!="") {

        $sql = ("UPDATE user SET pass = '$matkhaummoi1'WHERE email = '$email'")or die("hẹo" . mysql_error());
$query = mysql_query($sql);
        

    }
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
$accccc = date("Y-m-d H:i:s");
//echo ($accccc);



// $sqll = "INSERT INTO user (real_time)  VALUES (NULL,'testtes@gmail.com', 'xom ','xom ','$accccc','xom')";          
// $aa = mysql_query($sqll);





$sql = "SELECT * from user where email ='$email'";
$result = mysql_query($sql);

$data = mysql_fetch_assoc($result);


$cc = $data['id'];

$_SESSION['cc']= $cc;


?>
<html>
<head>
    <meta charset="UTF-8">
    <title>Chat Widget</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>

    <link rel="stylesheet" href="Main/chat/css/ccss.css">


</head>

<body>
<div class="container clearfix">
    <div class="people-list" id="people-list">
       
        <ul id = "list" class="list">
<!-- //////////////////////////////// -->
        </ul>
    </div>

    <div class="chat">
        <div class="chat-header clearfix">
            <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_01_green.jpg" alt="avatar"/>

            <div class="chat-about">
                <div class="chat-with">Họ tên: <?php echo $data['FirstName'] . ' ' . $data['LastName'] ?></div>
                <div class="chat-num-messages">email: <?php echo $email ?></div>
            </div>
            <i class="fa fa-star"></i>
        </div> <!-- end chat-header -->


        <div class="chat-history" id = "chat-history" >

            <form action="" method="post">
                <H3>Sửa thông tin: </H3>
                
                <div class="form-group">
                    <label for="pwd">First Name:</label>
                    <input class="form-control" name= "FFirst" placeholder="">
                </div>
                <div class="form-group">
                    <label for="pwd">Last Name:</label>
                    <input class="form-control" name = "LLast" placeholder="">
                </div>


                <button type="submit" name = "btn_save" class="btn btn-default">save</button>

                <H3>Thay mật khẩu: </H3>

                <div class="form-group">
                    <label for="pwd">mật khẩu cũ:</label>
                    <input type="password" name = "MkCu" class="form-control" id="pwd">
                </div>
                <div class="form-group">
                    <label for="pwd">mật khẩu mới:</label>
                    <input type="password" name = "Mkmoi"class="form-control" id="pwd">
                </div>
                <div class="form-group">
                    <label for="pwd">nhập lại mật khẩu mới:</label>
                    <input type="password" name = "nMkmoi"class="form-control" id="pwd">
                </div>
                <button type="submit" name = "btn_doiMk" class="btn btn-default">đổi mật khẩu</button>
            </form>


        </div> <!-- end chat-history -->


    </div> <!-- end container -->

  


    <!-- <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.0/handlebars.min.js'></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/list.js/1.1.1/list.min.js'></script> -->

    <script src="chat/js/index.js"></script>

    <script ype="text/javascript" src="Chat/chat/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="Chat/chat/js/GhiOnline.js"></script>

<script type="text/javascript" src="Chat/chat/js/load_list_ban.js"></script>


</body>
</html>
