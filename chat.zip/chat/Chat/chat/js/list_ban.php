  <?php session_start();?>
   <?php $conn=mysql_connect("localhost","root","") or die("can't connect this database");
mysql_select_db("testt",$conn);?>  

<?php
$cc = $_SESSION['cc'];


?>
            <?php


            $sql = "SELECT * from user ";   $result = mysql_query($sql);
            while ($row = mysql_fetch_assoc($result)) {


                if ($row['id'] != $cc) {

            date_default_timezone_set('Asia/Ho_Chi_Minh');
            $datetime = date("Y-m-d H:i:s");

           $ngon = abs (strtotime($datetime) -strtotime($row['real_time']));

         
        // echo $datetime->format("l");
         


                    ?>
                    <a href='Chat.php?ida=<?php echo $cc ?>&idb=<?php echo $row['id'] ?>'>
                    <li class="clearfix">
                        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar"/>
                        <div class="about">
                            <div class="name"><?php echo $row["LastName"] . " " . $row["FirstName"] ?>  </div>
                            <div class="status">
                                <i class="<?php
if ($ngon <5) {
             echo "fa fa-circle online";
         }
         else
         {
            echo"fa fa-circle offline";
         }
?>"></i> <?php
if ($ngon <5) {
             echo "Đang online";
         }
         else
         {
            echo"online gần nhất " . (string)$row['real_time'] ;
         }
?>
                            </div>
                        </div>
                    </li>
                    </a>


                    <?php
                }
            }
            ?>