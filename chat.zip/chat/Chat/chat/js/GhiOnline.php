 <?php session_start();?>
 <?php $conn=mysql_connect("localhost","root","") or die("can't connect this database");
mysql_select_db("testt",$conn);?>  

<?php
setOnLine();

function setOnLine(){

	$a = $_SESSION['user'] ;
echo $a;

 date_default_timezone_set('Asia/Ho_Chi_Minh');
 $time = date("Y-m-d H:i:s");
echo $time;
$sql = ("UPDATE user SET real_time = '$time' WHERE email = '$a'")or die("hẹo" . mysql_error());
$query = mysql_query($sql);

}





?>
