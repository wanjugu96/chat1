  <?php session_start();?>
   <?php $conn=mysql_connect("localhost","root","") or die("can't connect this database");
mysql_select_db("testt",$conn);?>  

 <?php

$idPhong = $_SESSION['idPhong'] ;
$ida = $_SESSION['ida'];
$Ten = $_SESSION['Ten'];
$Ten1 = $_SESSION['Ten1'];

  $sql= ("SELECT * from mess where idPhong = $idPhong ");
  $kk= mysql_query($sql);
  while ($row = mysql_fetch_assoc($kk)) {
      if ($row['idGui'] == $ida) {
?>
     <li>
            <div class="message-data">
              <span class="message-data-name"><i class="fa fa-circle online"></i> <?php echo $Ten; ?></span>
            </div>
            <div class="message my-message">
                  <?php  echo $row['messs']; ?>
            </div>
          </li>
        
       
<?php  

      }
      else
      {
        ?>
         <li class="clearfix">
            <div class="message-data align-right">
              <span class="message-data-name" ><?php echo $Ten1?></span> <i class="fa fa-circle me"></i>
            </div>
            <div class="message other-message float-right">

              <?php echo $row['messs'] ; ?>
            </div>
          </li>

         
<?php

      }
      }

?> 
          
          
          
          