
$(document).ready(function(){
  var intercal = setInterval(function()
  {
    $.ajax({
      url: 'Chat/chat/js/Ghionline.php'
    });

  },1000);

  
});


