<?php
include_once('CSDL/db.php');




// function get_msg($NAME){

// $query= ("SELECT * from mess where name= '{$NAME}' ")

// 	$run= mysql_query($query);
// 	while ($message = mysql_fetch_assoc($run)) {
// 			echo $message['messs'];
				
// 		}
	
// }



function send_msg($idNguoiGui,$idPhong,$mess){

if (!empty($idNguoiGui)&&empty($idPhong)&&!empty($mess) ) {

	 $query= "INSERT INTO `mess` (`id`, `idGui`, `idPhong`, `messs`) 
	 VALUES (NULL, $idNguoiGui, $idPhong, $mess)";

	 $run = mysql_query($query);
	 if ($run) {
	 		echo "thành công";
	 }
	 else
	 {
	 	echo "hẹo";
	 }

	# code...
}else
{
	return false;
}






}




?>