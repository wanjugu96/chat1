<?php session_start();?>
<!DOCTYPE html>
<?php
include_once('db.php');
/*include_once('chat_func.php');*/

?>


<?php

$ida=$_GET['ida'];
$idb=$_GET['idb'];





$sql = "SELECT * from user where id = '{$ida}' ";
$result = mysqli_query($conn,$sql);
$Ten;$TenDem;
while ($row = mysqli_fetch_assoc($result)) {
$TenDem = $row['LastName'];
$Ten    = $row['FirstName'];
}


$sql1 = "SELECT * from user where id = '{$idb}' ";
$result1 = mysqli_query($conn,$sql1);
$Ten1;$TenDem1;
while ($row1 = mysqli_fetch_assoc($result1)) {
$TenDem1 = $row1['LastName'];
$Ten1    = $row1['FirstName'];

}

$TenPhong1=$ida.$idb;
$TenPhong2=$idb.$ida;

  function KiemTraTen($so1,$so2) {
  $sql = "SELECT * from box ";
  $result = mysqli_query($conn,$sql);
  $a=0;
  
  while ($row = mysqli_fetch_assoc($result)) {
        // echo $row['name'];

        if ($row['name'] == $so1) {

          $a=1;
          
        }
        else{
          if ($row['name'] == $so2) {
          $a=2;
          }
         
        }
      }
       
       return $a;
  
}

$concac = KiemTraTen($TenPhong1,$TenPhong2);

if ($concac == 1) {
 // echo " </br> đã có phòng phong tên với TenPhong1";
  $sql = "SELECT * from box where name = $TenPhong1 ";
  $result = mysql_query($sql);
  $row = mysql_fetch_assoc($result);
  $idPhong = $row['id'];
 // echo '<br/> id phòng'. $idPhong;

}
else if($concac == 2){
 // echo " </br> đã có phòng phong tên với TenPhong2";
  $sql = "SELECT * from box where name = $TenPhong2 ";
  $result = mysql_query($sql);
  $row = mysql_fetch_assoc($result);
  $idPhong = $row['id'];
//  echo '<br/> id phòng'. $idPhong;
}else{

 // echo "chưa có phòng. phải tạo phòng";
    $sql = "INSERT INTO `box` (`id`, `idUser1`, `idUser2`, `name`) 
          VALUES (NULL,$ida , $idb, $TenPhong1)";
          $result = mysqli_query($conn,$sql);
}

?>

<html >

<head>
  <meta charset="UTF-8">
  <title>Chat Widget</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="Chat/chat/css/style.css">

  
</head>

<body>
    <div class="container clearfix">
    
    
    <div class="chat" id = "messages">





      <div class="chat-header clearfix">
        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_01_green.jpg" alt="avatar" />
        
        <div class="chat-about">
          <div class="chat-with">Chat with <?php echo $Ten1 .' '.  $TenDem1; ?></div>
          
        </div>
        <i class="fa fa-star"></i>
      </div> <!-- end chat-header -->
      
      <div class="chat-history" id="chat-history">
        <ul>



        </ul>
        
      </div> <!-- end chat-history -->
  
<?php

$_SESSION['idPhong']=$idPhong;
$_SESSION['ida']=$ida;
$_SESSION['Ten']=$Ten;
$_SESSION['Ten1']=$Ten1;

if (isset($_POST["btn"]) && ($_POST["message-to-send"])!="") {

    $idNguoiGui = $ida;
    $messss = $_POST["message-to-send"];

  //echo $messss; 
 $sql = "INSERT INTO `mess` (`id`, `idGui`, `idPhong`,`messs`) 
          VALUES (NULL, $idNguoiGui , $idPhong, '$messss')";
          $result = mysqli_query($conn,$sql);

$messss="";

}

?> 

<form id= "bb" action="" method="post">
 <div class="chat-message clearfix">
        <textarea  id ="cc" name="message-to-send" placeholder ="Type your message" rows="3"></textarea>
                
        <i class="fa fa-file-o"></i> &nbsp;&nbsp;&nbsp;
        <i class="fa fa-file-image-o"></i>
        
        <button onClick="Scroll()" name="btn" type="submit" id="abc" >send</button>

      </div> <!-- end chat-message -->
  
</form>
      
     
        
      
      


      
    </div> <!-- end chat -->
    
  </div> <!-- end container -->

<script ype="text/javascript" src="Chat/chat/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="Chat/chat/js/index.js"></script>

</body>
</html>
