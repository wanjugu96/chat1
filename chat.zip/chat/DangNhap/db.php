<?php

$conn=mysqli_connect("localhost","root","", "test") or die("can't connect this database");
mysqli_select_db($conn,"test");


?>