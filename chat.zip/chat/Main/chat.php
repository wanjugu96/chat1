<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Chat Widget</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="chat/css/ccss.css">

  
</head>

<body>
    <div class="container clearfix">
    <div class="people-list" id="people-list">
      <div class="search">
        <input type="text" placeholder="search" />
        <i class="fa fa-search"></i>
      </div>
      <ul class="list">
        
        
        <li class="clearfix">
        <a href="mess.php">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 7 mins ago
            </div>
          </div>
          </a>
        </li>
        <li class="clearfix">
        <a href="mess.php">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 7 mins ago
            </div>
          </div>
          </a>
        </li>
        <li class="clearfix">
        <a href="mess.php">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 7 mins ago
            </div>
          </div>
          </a>
        </li>
        <li class="clearfix">
        <a href="mess.php">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 7 mins ago
            </div>
          </div>
          </a>
        </li>
        <li class="clearfix">
        <a href="mess.php">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 7 mins ago
            </div>
          </div>
          </a>
        </li>
        <li class="clearfix">
        <a href="mess.php">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 7 mins ago
            </div>
          </div>
          </a>
        </li>
        
        <li class="clearfix">
        <a href="mess.php">
        </a>
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle online"></i> online
            </div>
          </div>
        </li>
        
        <li class="clearfix">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_02.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle online"></i> online
            </div>
          </div>
        </li>
        
        <li class="clearfix">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_03.jpg" alt="avatar" />
          <div class="about">
            <div class="name">Chuối</div>
            <div class="status">
              <i class="fa fa-circle online"></i> online
            </div>
          </div>
        </li>
        
        <li class="clearfix">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_03.jpg" alt="avatar" />
          <div class="about">
            <div class="name">cam</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 30 mins ago
            </div>
          </div>
        </li>
        
        <li class="clearfix">
          <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_03.jpg" alt="avatar" />
          <div class="about">
            <div class="name">cam</div>
            <div class="status">
              <i class="fa fa-circle offline"></i> left 10 hours ago
            </div>
          </div>
        </li>
        
   
      </ul>
    </div>
    
    <div class="chat">
      <div class="chat-header clearfix">
        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_01_green.jpg" alt="avatar" />
        
        <div class="chat-about">
          <div class="chat-with">Họ và tên</div>
          <div class="chat-num-messages">email</div>
        </div>
        <i class="fa fa-star"></i>
      </div> <!-- end chat-header -->
      


      <div class="chat-history">

      <form>
      <H3>Sửa thông tin: </H3>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" placeholder="manh@gmail.com">
  </div>
  <div class="form-group">
    <label for="pwd">First Name:</label>
    <input  class="form-control" id="pwd" placeholder="mạnh" >
  </div>
  <div class="form-group">
    <label for="pwd">Last Name:</label>
    <input  class="form-control" id="pwd" placeholder="chuối">
  </div>

  
  
  <button type="submit" class="btn btn-default">save</button>

  <H3>Thay mật khẩu: </H3>

  <div class="form-group">
    <label for="pwd">mật khẩu cũ:</label>
    <input  type="password" class="form-control" id="pwd">
  </div>
  <div class="form-group">
    <label for="pwd">mật khẩu mới:</label>
    <input  type="password" class="form-control" id="pwd">
  </div>
  <div class="form-group">
    <label for="pwd">nhập lại mật khẩu mới:</label>
    <input  type="password" class="form-control" id="pwd">
  </div>
  <button type="submit" class="btn btn-default">đổi mật khẩu</button>
</form>
       
        
      </div> <!-- end chat-history -->
      
     
    
  </div> <!-- end container -->


  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/handlebars.js/3.0.0/handlebars.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/list.js/1.1.1/list.min.js'></script>

    <script src="chat/js/index.js"></script>

</body>
</html>
